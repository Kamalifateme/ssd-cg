<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$config['update_check'] = 'http://fo.shuleportal.com/releases/current-release-versions.php';
$config['update_url'] = 'http://fo.shuleportal.com/releases/UPDATES/';

// Used for Installation purposes
$config['version'] = '1.6';
/* End of file version.php */