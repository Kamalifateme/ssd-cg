<?php

$lang['migration_none_found']			= "Nebyly nalezeny žádné migrace";
$lang['migration_not_found']			= "Tuto migraci nelze nalézt.";
$lang['migration_multiple_version']		= "Tohle jsou migrace se stejným číslem verze: %d.";
$lang['migration_class_doesnt_exist']	= "Třída migrace \"%s\" nebyla nalezena.";
$lang['migration_missing_up_method']	= "Třídě migrace \"%s\" chybí 'up' metoda.";
$lang['migration_missing_down_method']	= "Třídě migrace \"%s\" chybí 'down' metoda.";
$lang['migration_invalid_filename']		= "Migrace \"%s\" má špatný název souboru.";


/* End of file migration_lang.php */
/* Location: ./system/language/czech/migration_lang.php */