<?php

$lang['migration_none_found']			= "Nu au fost găsite migrații.";
$lang['migration_not_found']			= "Această migrare nu a putut fi găsită.";
$lang['migration_multiple_version']		= "Acestea sunt multiple migrații cu același număr de versiune: %d.";
$lang['migration_class_doesnt_exist']	= "Clasa de migrare \"%s\" nu a putut fi gasită.";
$lang['migration_missing_up_method']	= "Clasa de migrare \"%s\" lipseşte printr-o metodă de tip 'up'.";
$lang['migration_missing_down_method']	= "Clasa de migrare \"%s\" lipseşte printr-o metodă de tip 'down'.";
$lang['migration_invalid_filename']		= "Migrarea \"%s\" are un nume de fişier invalid.";


/* End of file migration_lang.php */
/* Location: ./system/language/english/migration_lang.php */
